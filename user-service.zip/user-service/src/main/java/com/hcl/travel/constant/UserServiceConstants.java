package com.hcl.travel.constant;

public interface UserServiceConstants {

}
